local castleDeath = CreatureEvent("castleDeath")

-- Definição da posição de saída da dungeon
local exitDungeonPos = Position(32369, 32241, 7)

function castleDeath.onPrepareDeath(player)

	local pos = player:getPosition()
	local z_levels = {7, 6, 5, 4, 3}

	for _, z in ipairs(z_levels) do
		local fromPos = Position(32090, 32311, z)
		local toPos = Position(32134, 32353, z)

		if pos:isInRange(fromPos, toPos) then
			player:teleportTo(exitDungeonPos) -- Teleporta o jogador para fora da arena
			player:addHealth(100000000)
			player:addMana(100000000)
			return false -- Cancela a morte dentro da arena
		end
	end

	return true -- Permite a morte fora da arena
end

castleDeath:register()