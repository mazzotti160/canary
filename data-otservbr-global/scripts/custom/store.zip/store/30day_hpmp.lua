local dust = Action()

function dust.onUse(player, item, fromPosition, target, toPosition, isHotkey)
	local kv_hpmp_expiry = player:kv():get("buff-hpmp")
	local seven_days = 30 * 24 * 60 * 60

	if kv_hpmp_expiry and kv_hpmp_expiry >= os.time() then
		player:say("You already have double health and mana until " .. os.date('%d/%m/%Y - %H:%M:%S', kv_hpmp_expiry) .. " Horario de Brasilia!", TALKTYPE_MONSTER_SAY)
		return true
	elseif player:getStorageValue(4591046545002) >= os.time() then
		player:say("You already have double health and mana until " .. os.date('%d/%m/%Y - %H:%M:%S', player:getStorageValue(4591046545002)) .. " Horario de Brasilia!", TALKTYPE_MONSTER_SAY)
		return true
	else
		player:say("Congratulations! Your health and mana have been doubled for 30 days.", TALKTYPE_MONSTER_SAY)
		player:kv():set("buff-hpmp", os.time() + seven_days) -- Set the KV entry
		--player:setStorageValue(4591046545002, os.time() + seven_days) --still setting storage
		item:remove(1)
	end
end

dust:id(31675)
dust:register()
