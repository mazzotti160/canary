local dust = Action()

function dust.onUse(player, item, fromPosition, target, toPosition, isHotkey)
	local kv_regen_expiry = player:kv():get("buff-regen")
	local seven_days = 7 * 24 * 60 * 60

	if kv_regen_expiry and kv_regen_expiry >= os.time() then
		player:say("You already have regen until " .. os.date('%d/%m/%Y - %H:%M:%S', kv_regen_expiry) .. " Horario de Brasilia!", TALKTYPE_MONSTER_SAY)
		return true
	elseif player:getStorageValue(4591046545001) >= os.time() then
		player:say("You already have regen until " .. os.date('%d/%m/%Y - %H:%M:%S', player:getStorageValue(4591046545001)) .. " Horario de Brasilia!", TALKTYPE_MONSTER_SAY)
		return true
	else
		player:say("Congratulations! You have boosted your regen for 7 days.", TALKTYPE_MONSTER_SAY)
		player:kv():set("buff-regen", os.time() + seven_days)
		--player:setStorageValue(4591046545001, os.time() + seven_days)
		item:remove(1)
	end
end

dust:id(33892)
dust:register()
