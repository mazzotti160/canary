local storeregen = CreatureEvent("storeregen")

local condition = Condition(CONDITION_REGENERATION)
condition:setParameter(CONDITION_PARAM_TICKS, -1)
condition:setParameter(CONDITION_PARAM_HEALTHGAIN, 50)
condition:setParameter(CONDITION_PARAM_HEALTHTICKS, 2000) -- 3 segundos
condition:setParameter(CONDITION_PARAM_MANAGAIN, 100)
condition:setParameter(CONDITION_PARAM_MANATICKS, 2000) -- 3 segundos

function storeregen.onLogin(player)
	local kv_regen_expiry = player:kv():get("buff-regen")

	if kv_regen_expiry and kv_regen_expiry >= os.time() then
		player:addCondition(condition)
	else
		player:removeCondition(condition)
    end
    return true
end

storeregen:register()